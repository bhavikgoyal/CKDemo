﻿function masterKO()
{

}